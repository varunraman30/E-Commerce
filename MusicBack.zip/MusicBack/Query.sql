CREATE TABLE category (
	id IDENTITY,
	name VARCHAR(50),
	description VARCHAR(255),
	image_url VARCHAR(50),
	is_active BOOLEAN,
	CONSTRAINT pk_category_id PRIMARY KEY (id) 
);

INSERT INTO category (name, description,image_url,is_active) VALUES ('English', 'This is description for English category!', 'CAT_1.png', true);
INSERT INTO category (name, description,image_url,is_active) VALUES ('Hindi', 'This is description for Hindi category!', 'CAT_2.png', true);
INSERT INTO category (name, description,image_url,is_active) VALUES ('Tamil', 'This is description for Tamil category!', 'CAT_3.png', true);
INSERT INTO category (name, description,image_url,is_active) VALUES ('Malayalam', 'This is description for Malayalam category!', 'CAT_4.png', true);

CREATE TABLE user_detail (
	id IDENTITY,
	first_name VARCHAR(50),
	last_name VARCHAR(50),
	role VARCHAR(50),
	enabled BOOLEAN,
	password VARCHAR(60),
	email VARCHAR(100),
	contact_number VARCHAR(15),	
	CONSTRAINT pk_user_id PRIMARY KEY(id)
);

INSERT INTO user_detail 
(first_name, last_name, role, enabled, password, email, contact_number) 
VALUES ('Oliver', 'Queen', 'ADMIN', true, '$2a$06$ORtBskA2g5Wg0HDgRE5ZsOQNDHUZSdpJqJ2.PGXv0mKyEvLnKP7SW', 'oliver@gmail.com', '8888888888');
INSERT INTO user_detail 
(first_name, last_name, role, enabled, password, email, contact_number) 
VALUES ('Barry', 'Allen', 'SUPPLIER', true, '$2a$06$bzYMivkRjSxTK2LPD8W4te6jjJa795OwJR1Of5n95myFsu3hgUnm6', 'barry@gmail.com', '9999999999');
INSERT INTO user_detail 
(first_name, last_name, role, enabled, password, email, contact_number) 
VALUES ('Clark', 'Kent', 'SUPPLIER', true, '$2a$06$i1dLNlXj2uY.UBIb9kUcAOxCigGHUZRKBtpRlmNtL5xtgD6bcVNOK', 'clark@gmail.com', '7777777777');
INSERT INTO user_detail 
(first_name, last_name, role, enabled, password, email, contact_number) 
VALUES ('Bruce', 'Wayne', 'USER', true, '$2a$06$4mvvyO0h7vnUiKV57IW3oudNEaKPpH1xVSdbie1k6Ni2jfjwwminq', 'bruce@gmail.com', '7777777777');

CREATE TABLE product (
	id IDENTITY,
	code VARCHAR(20),
	name VARCHAR(50),
	artist VARCHAR(50),
	audio VARCHAR(50),
	song VARCHAR(50),
	description VARCHAR(255),
	unit_price DECIMAL(10,2),
	quantity INT,
	is_active BOOLEAN,
	category_id INT,
	supplier_id INT,
	purchases INT DEFAULT 0,
	views INT DEFAULT 0,
	CONSTRAINT pk_product_id PRIMARY KEY (id),
 	CONSTRAINT fk_product_category_id FOREIGN KEY (category_id) REFERENCES category (id),
	CONSTRAINT fk_product_supplier_id FOREIGN KEY (supplier_id) REFERENCES user_detail(id),	
);	

INSERT INTO user_detail 
(first_name, last_name, role, enabled, password, email, contact_number) 
VALUES ('Oliver', 'Queen', 'ADMIN', true, '$2a$06$ORtBskA2g5Wg0HDgRE5ZsOQNDHUZSdpJqJ2.PGXv0mKyEvLnKP7SW', 'oliver@gmail.com', '8888888888');
INSERT INTO user_detail 
(first_name, last_name, role, enabled, password, email, contact_number) 
VALUES ('Barry', 'Allen', 'SUPPLIER', true, '$2a$06$bzYMivkRjSxTK2LPD8W4te6jjJa795OwJR1Of5n95myFsu3hgUnm6', 'barry@gmail.com', '9999999999');
INSERT INTO user_detail 
(first_name, last_name, role, enabled, password, email, contact_number) 
VALUES ('Clark', 'Kent', 'SUPPLIER', true, '$2a$06$i1dLNlXj2uY.UBIb9kUcAOxCigGHUZRKBtpRlmNtL5xtgD6bcVNOK', 'clark@gmail.com', '7777777777');
INSERT INTO user_detail 
(first_name, last_name, role, enabled, password, email, contact_number) 
VALUES ('Bruce', 'Wayne', 'USER', true, '$2a$06$4mvvyO0h7vnUiKV57IW3oudNEaKPpH1xVSdbie1k6Ni2jfjwwminq', 'bruce@gmail.com', '7777777777');

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('divide', 'Divide', 'Ed Sheeran','shapeofyou','Shape of You', 'Divide is the third studio album by Ed Sheeran, following Plus and Multiply. Was released on March 3	2017', 200, 5, true, 1, 2, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('rangdebasanti', 'Rang De Basanti','A.R.Rahman','roobaroo','Roobaroo', 'The Soundtrack to the 2006 film Rang De Basanti was released by SONY BMG on 8 December 2005', 180, 2, true, 2, 3, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('vaaranamaayiram', 'Vaaranam Aayiram','Harris Jayaraj','adiyaekolluthey','Adiyae Kolluthey','The Soundtrack to the 2008 film Vaaranam Aayiram was released by SONY BMG on 24 September 2008', 150, 5, true, 3, 2, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('premam', ' Premam', 'Rajesh Murugesan','aluvapuzha','Aluva Puzha', 'The Soundtrack and the background score to the 2015 film Premam was released by Muzik 24x7 on 26 March 2015', 200, 3, true, 4, 4, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('redpillblues', 'Red Pill Blues', 'Maroon 5','wait','Wait', 'Red Pill Blues is the sixth studio album by American pop rock band Maroon 5. Was released on November 3 2017', 210, 5, true, 1, 1, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('aashiqui2', 'Aashiqui 2','Arijit Singh','tumhiho','Tum Hi Ho', 'The Soundtrack to the 2013 film Aaashiqui 2 was released by T Series on 3 April 2013', 180, 2, true, 2, 3, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('meesayamurukku', 'Meesaya Murukku', 'Hip Hop Tamizha','maatikichu','Maatikuchu', 'The Soundtrack to the 2017 film Meesaya Murukku composed by Adhi was released by VMS Music Records on 21 April 2017', 210, 5, true, 3, 1, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('ustadhotel', ' Ustad Hotel', 'Gopi Sundar','appangalembadum','Appangal Embadum', 'The Soundtrack to the 2012 film Ustad Hotel was released by Satyam Audios on 13 July 2012', 200, 3, true, 4, 4, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('evolve', 'Evolve', 'Imagine Dragons','believer','Believer', 'Evolve (stylized as ƎVOLVE) is the third studio album by American rock band Imagine Dragons, released on June 23, 2017 through KIDinaKORNER and Interscope Records', 210, 5, true, 1, 1, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('rangdebasanti', 'Baar Baar Dekho','Amaal Mallik','kaalachashma','Kaala Chashma', 'The Soundtrack to the 2016 film Baar Baar Dekho was released by Zee Music Company on 27 July 2016', 180, 2, true, 2, 3, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('mersal', 'Mersal', 'A.R.Rahman','aalaporan','Aalaporan Thamizhan', 'The Soundtrack to the 2017 film Mersal was released by Sony Music on 20 August 2017', 210, 5, true, 3, 1, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('charlie', ' Charlie', 'Gopi Sundar','puthumazhayai','Puthumazhayai', 'The Soundtrack to the 2015 film Charlie was released by Muzik 24x7 on 7 December 2015', 200, 3, true, 4, 4, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('thesethingshappen', 'These Things Happen', 'G-Eazy','imeanit','I Mean It', 'These Things Happen is the debut studio album by American rapper G-Eazy. It was released on June 23, 2014, by RCA Records', 210, 5, true, 1, 1, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('aedilhaimushkil', 'Ae Dil Hai Mushkil','Pritam','channamereya','Channa Mereya', 'The Soundtrack to the 2016 film Ae Dil Hai Mushkil was released by SONY Music India on 26 October 2016', 180, 2, true, 2, 3, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('thanioruvan', 'Thani Oruvan', 'Hip Hop Tamizha','theemaidhanvellum','Theemai Dhan Vellum', 'The Soundtrack to the 2015 film Thani Oruvan composed by Adhi was released by Sony Music on 23 July 2015', 210, 5, true, 3, 1, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('ennunintemoideen', ' Ennu Ninte Moideen', 'M. Jayachandran','kaathirunnu','Kaathirunnu', 'The Soundtrack to the 2015 film Ennu Ninte Moideen was released by Satyam Audios on 	7 September 2015', 200, 3, true, 4, 4, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('recovery', 'Recovery', 'Eminem','notafraid','Not Afriad', 'Recovery is the seventh studio album by American rapper Eminem. It was released on June 18, 2010, by Aftermath Entertainment, Shady Records, and Interscope Records', 210, 5, true, 1, 1, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('ztudentoftheyear', 'Student of The Year','Vishal-Shekhar','discodeewane','Disco Deewane', 'The Soundtrack to the 2012 film Student of The Year was released by Sony Music India on 31 August 2012', 180, 2, true, 2, 3, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('3', '3 (Moonu)', 'Anirudh Ravichander','whythiskolaveri','Why This Kolaveri', 'The Soundtrack to the 2012 film 3 was released by Sony Music on 28 December 2011', 210, 5, true, 3, 1, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('bangaloredays', ' Bangalore Days', 'Gopi Sunder','aluvapuzha','Aluva Puzha', 'The Soundtrack to the 2014 film Bangalore Days was released by Muzik 24x7 on 30 March 2014', 200, 3, true, 4, 4, 0, 0 );

INSERT INTO product (code, name, artist, audio,song, description, unit_price, quantity, is_active, category_id, supplier_id, purchases, views)
VALUES ('red', 'Red', 'Taylor Swift','22','22', 'Red is the fourth studio album by American singer-songwriter Taylor Swift. It was released on October 22, 2012, by Big Machine Records', 210, 5, true, 1, 1, 0, 0 );


