package var.ram.MusicBack.test;

import org.junit.BeforeClass;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import var.ram.MusicBack.dao.CategoryDAO;
import var.ram.MusicBack.model.Category;

public class CategoryTestCase {

	private static AnnotationConfigApplicationContext context;

	private static CategoryDAO categoryDAO;

	private Category category;

	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("var.ram.MusicBack");
		context.refresh();
		categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
	}
}
